from multiprocessing import Pool, cpu_count
import numpy as np
import itertools
import pandas as pd
from random import sample
import multiprocessing 
from multiprocessing.shared_memory import ShareableList
# function to be applied for each element
from time import perf_counter
from collections import Counter
import os
import logging

logging.basicConfig(filename='../logs/gera_combinacoes_com_ternos.log',level=logging.INFO, format=' %(asctime)s - %(levelname)s - %(funcName)s - %(lineno)d - %(message)s')
logging.info(f'Inicio...')

t1 = perf_counter()

def ret_dezenas(d1,d2,d3,d4,d5,d6):
    return [d1,d2,d3,d4,d5,d6]

# s_dezenas
def ler_arquivo_mega():
    sorteios_df = pd.read_excel('Mega-Sena.xlsx', parse_dates=['Data do Sorteio'])
    sorteios_df.fillna('', inplace=True)
    sorteios_df.replace('\n',' ', regex=True, inplace=True)
    colunas = ['Bola1','Bola2','Bola3','Bola4','Bola5','Bola6']
    dez_sorteadas_df  = sorteios_df[colunas]
    dez_sorteadas_df['dezenas'] = dez_sorteadas_df.apply(
        lambda x:ret_dezenas(x['Bola1'],x['Bola2'],x['Bola3'],x['Bola4'],x['Bola5'],x['Bola6'],), axis=1
        )
    s_dezenas = dez_sorteadas_df['dezenas'] # 2.616
    return s_dezenas

# ternos_sorteados_n
def retorna_ternos_sorteados(s_dezenas):
    ternos_sorteados = []
    for aposta in s_dezenas:
        for terno in itertools.combinations(aposta,3):
            ternos_sorteados.append(terno)    
    ternos_sorteados_c = Counter(ternos_sorteados)
    print(f'ternos_sorteados: {len(ternos_sorteados)}')
    # ternos_sorteados_n = list([item for item in ternos_sorteados_c if ternos_sorteados_c[item]>1])     
    
    # elimina os duplicados
    # ternos_sorteados_n = list([item for item in ternos_sorteados_c])
         
    # print(f'lista de ternos sem duplicados: {len(ternos_sorteados_n)}')    
    print(f'lista de ternos completa: {len(ternos_sorteados_c)}')    
    return ternos_sorteados   


def pool_initializer(TERNOS):
    global lista_ternos
    lista_ternos = TERNOS


def conta_ternos(dezena):
    global lista_ternos
    qtde = 0
    tot = 0
    for terno in lista_ternos:
        qtde = (len((list((set(terno) & set(dezena))))))
        if qtde == 3:
            tot += 1
    return tot


def gera_combinacoes(qtde):
    numeros = list(range(1,61))
    combinacoes = itertools.combinations(numeros,qtde) 
    s_apostas_possiveis = (list(combinacoes))   
    return s_apostas_possiveis

if __name__ == "__main__":
    s_dezenas = ler_arquivo_mega()
    dezenas_sorteadas = list(gera_combinacoes(6))
  
    ternos_sorteados = retorna_ternos_sorteados(s_dezenas)

    n = 500_000
    l_apostas_possiveis = x = [dezenas_sorteadas[i:i + n] for i in range(0, len(dezenas_sorteadas), n)] 

    # ultimo_arquivo = -1 # 04/09/2023
    ultimo_arquivo = 22 # 04/09/2023
    logging.info('Iniciando loop para gerar os arquivos. Iniciando em arquivo id: {ultimo_arquivo}')
    for id_lista in range(len(l_apostas_possiveis)):
        logging.info(f'Grando arquivo id {id_lista}')
        if id_lista > ultimo_arquivo:
            pool = Pool(
                processes=cpu_count(), 
                initializer=pool_initializer, 
                initargs=([ternos_sorteados]))
            res = pool.map(conta_ternos, l_apostas_possiveis[id_lista])
            filecsv = f'filecsv_comb_terno_{id_lista}.csv'
            pd.Series(list(res)).to_csv('E:/Arquivos/devops/melhor-aposta-ms-final/multi_proc_final_2023/resultado_com_terno/' + filecsv, header=False, index=False)

            print(f'Tempo Total (s): {perf_counter() - t1} \
                \nTempo Total (h): {((perf_counter() - t1)/60/60)}')
            logging.info(f'Gravado arquivo {filecsv}')

    print(f'Tempo geral Total (s): {perf_counter() - t1} \
        \nTempo geral Total (h): {((perf_counter() - t1)/60/60)}')
    logging.info('Fim da execução.')