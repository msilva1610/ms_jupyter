from multiprocessing import Pool, cpu_count
import numpy as np
import itertools
import pandas as pd
from random import sample
import multiprocessing 
from multiprocessing.shared_memory import ShareableList
# function to be applied for each element
from time import perf_counter
from collections import Counter
import os
import logging

logging.basicConfig(filename='../logs/gera_combinacoes_com_quadras.log',level=logging.INFO, format=' %(asctime)s - %(levelname)s - %(funcName)s - %(lineno)d - %(message)s')
logging.info(f'Inicio...')

t1 = perf_counter()



def conta_ternos_real(terno):
    C = np.isin(lista_ternos_np,terno, assume_unique=False)
    D = np.count_nonzero(C, axis=1, keepdims=True)
    D = D.squeeze()
    qtde = np.count_nonzero(D == 3)
    return qtde


def conta_quadras_real(quadra):
    C = np.isin(lista_quadras_np, quadra, assume_unique=False)
    D = np.count_nonzero(C, axis=1, keepdims=True)
    D = D.squeeze()
    qtde = np.count_nonzero(D == 4)
    return qtde


def conta_quinas_real(quina):
    C = np.isin(lista_quinas_np, quina, assume_unique=False)
    D = np.count_nonzero(C, axis=1, keepdims=True)
    D = D.squeeze()
    qtde = np.count_nonzero(D == 4)
    return qtde


def gera_ter(lista):
    resultado = itertools.combinations(lista,3)
    return [d for d in resultado]


def ret_dezenas(d1,d2,d3,d4,d5,d6):
    return [d1,d2,d3,d4,d5,d6]


def GeraCombinacoes(dezenasSorteios, numDezenas):
    return itertools.combinations(dezenasSorteios, numDezenas)


def conta_ternos(dezenas):
    qtde_ternos = 0
    for terno in lista_ternos:
        qtde = len(list(set(terno) & set(dezenas))) # Encontra os iguais
        if qtde == 3:
            qtde_ternos += 1
    return qtde_ternos


def conta_quadras(dezenas):
    qtde_quadras = 0
    for terno in lista_quadras:
        qtde = len(list(set(terno) & set(dezenas))) # Encontra os iguais
        if qtde == 4:
            qtde_quadras += 1
    return qtde_quadras


def conta_quinas(dezenas):
    qtde_quinas = 0
    for terno in lista_quinas:
        qtde = len(list(set(terno) & set(dezenas))) # Encontra os iguais
        if qtde == 5:
            qtde_quinas += 1
    return qtde_quinas


def conta_ternos_combinacoes(dezenas):
    qtde_ternos = 0
    for terno in lista_ternos:
        qtde = len(list(set(terno) & set(dezenas))) # Encontra os iguais
        if qtde == 3:
            qtde_ternos += 1
    return qtde_ternos


def ler_arquivo_mega():
    global pareto_ternos, pareto_quadras, pareto_quinas, lista_ternos, lista_quadras, lista_quinas

    sorteios_df = pd.read_excel('Mega-Sena.xlsx', parse_dates=['Data do Sorteio'])
    sorteios_df.fillna('', inplace=True)
    sorteios_df.replace('\n',' ', regex=True, inplace=True)
    colunas = ['Bola1','Bola2','Bola3','Bola4','Bola5','Bola6']
    dez_sorteadas_df  = sorteios_df[colunas]
    dez_sorteadas_df['dezenas'] = dez_sorteadas_df.apply(
        lambda x:ret_dezenas(x['Bola1'],x['Bola2'],x['Bola3'],x['Bola4'],x['Bola5'],x['Bola6'],), axis=1
        )
    
    df = sorteios_df

    lista_ternos = []
    for i in df.itertuples():
        dezenas = getattr(i, "dezenas")
        for comb in GeraCombinacoes(dezenas,3):
            d = list(comb)
            d.sort()
            lista_ternos.append(d)

    lista_quadras = []
    for i in df.itertuples():
        dezenas = getattr(i, "dezenas")
        for comb in GeraCombinacoes(dezenas,4):
            d = list(comb)
            d.sort()
            lista_quadras.append(d)


    lista_quinas = []
    for i in df.itertuples():
        dezenas = getattr(i, "dezenas")
        for comb in GeraCombinacoes(dezenas,5):
            d = list(comb)
            d.sort()
            lista_quinas.append(d)


    df['ternos'] = df.apply(lambda x:conta_ternos(x['dezenas'],), axis = 1)
    df['quadras'] = df.apply(lambda x:conta_quadras(x['dezenas'],), axis = 1)
    df['quinas'] = df.apply(lambda x:conta_quinas(x['dezenas'],), axis = 1)

    colunas = ['ternos','quadras','quinas']
    comb_ter_qua_qui_df = df.groupby(by=colunas).count()[['Concurso']].sort_values('Concurso', ascending=False).reset_index()

    comb_ter_qua_qui_df.rename(columns={'Concurso': 'total_combs'}, inplace=True)
    comb_ter_qua_qui_df['pareto']   = comb_ter_qua_qui_df['total_combs']/comb_ter_qua_qui_df['total_combs'].sum()
    comb_ter_qua_qui_df['perc_sum']   = (comb_ter_qua_qui_df['pareto'].cumsum()/comb_ter_qua_qui_df['pareto'].sum())*100

    comb_ter_qua_qui_df['pareto'] = comb_ter_qua_qui_df['pareto']*100
    comb_ter_qua_qui_df.loc[
        comb_ter_qua_qui_df['perc_sum'] <= 81
    ]

    pareto_ternos = comb_ter_qua_qui_df['ternos'].values
    pareto_quadras = comb_ter_qua_qui_df['quadras'].values
    pareto_quinas = comb_ter_qua_qui_df['quinas'].values


# ternos_sorteados_n
def retorna_ternos_sorteados(s_dezenas):
    ternos_sorteados = []
    for aposta in s_dezenas:
        for terno in itertools.combinations(aposta,4):
            ternos_sorteados.append(terno)    
    ternos_sorteados_c = Counter(ternos_sorteados)
    print(f'Quadras s: {len(ternos_sorteados)}')
    print(f'lista de quadras completa: {len(ternos_sorteados_c)}')    
    return ternos_sorteados   


def pool_initializer(TERNOS):
    global lista_ternos
    lista_ternos = TERNOS


def conta_ternos(dezena):
    global lista_ternos
    qtde = 0
    tot = 0
    for terno in lista_ternos:
        qtde = (len((list((set(terno) & set(dezena))))))
        if qtde == 3:
            tot += 1
    return tot


def gera_combinacoes(qtde):
    numeros = list(range(1,61))
    combinacoes = itertools.combinations(numeros,qtde) 
    s_apostas_possiveis = (list(combinacoes))   
    return s_apostas_possiveis

if __name__ == "__main__":
    s_dezenas = ler_arquivo_mega()
    dezenas_sorteadas = list(gera_combinacoes(6))
  
    # ternos_sorteados = retorna_ternos_sorteados(s_dezenas)

    # n = 500_000
    # l_apostas_possiveis = x = [dezenas_sorteadas[i:i + n] for i in range(0, len(dezenas_sorteadas), n)] 

    lista_ternos_np = np.array(lista_ternos)
    lista_quadras_np = np.array(lista_quadras)
    lista_quinas_np = np.array(lista_quinas)

    # pool = Pool(
    #     processes=cpu_count(), 
    #     initializer=pool_initializer, 
    #     initargs=([ternos_sorteados]))
    # res = pool.map(conta_ternos, l_apostas_possiveis[id_lista])
    # filecsv = f'filecsv_comb_quadra_{id_lista}.csv'
    # pd.Series(list(res)).to_csv('E:/Arquivos/devops/melhor-aposta-ms-final/multi_proc_final_2023/resultado_com_quadra/' + filecsv, header=False, index=False)

